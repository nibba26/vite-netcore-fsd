export default function HomePage() {
    return <div className="p-6">Welcome to the protected home page!</div>;
}