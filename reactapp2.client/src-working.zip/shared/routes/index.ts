export const routes = {
    WELCOME: '/',
    CATEGORY: '/category'
}
