export interface CurrentUser {
    userId: string;
    name: string;
    email: string;
    roles: string[];
}