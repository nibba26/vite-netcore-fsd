export const API_URL = `${import.meta.env.VITE_API_URL}/api`
export const JSONPLACEHOLDER_API_URL = 'https://jsonplaceholder.typicode.com'
